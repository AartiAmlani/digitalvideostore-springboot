package com.example.restapidigitalvideostore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapiDigitalvideostoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapiDigitalvideostoreApplication.class, args);
	}

}
